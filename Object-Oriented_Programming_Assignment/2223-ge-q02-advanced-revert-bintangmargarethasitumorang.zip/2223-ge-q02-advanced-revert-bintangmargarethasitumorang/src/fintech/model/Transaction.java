package fintech.model;

/**
 * 12S21006 - Weny Sihol Marto Sitinjak
 * 12S21023 - Bintang Margaretha Situmorang
 */
public class Transaction {

    private int id;
    private String accountName;
    private String receiverName;
    private double balance = 0.0;
    private double amount = 0.0;
    private String postedAt;
    private String note;

    public Transaction(int id, String accountName, double amount, String postedAt, String note) {
        this.id = id;
        this.accountName = accountName;
        this.amount = amount;
        this.postedAt = postedAt;
        this.note = note;
        this.balance += amount;
    }

    public Transaction(int id, String accountName, String receiverName, double amount, String postedAt, String note) {
        this.id = id;
        this.accountName = accountName;
        this.receiverName = receiverName;
        this.amount = amount;
        this.postedAt = postedAt;
        this.note = note;
        this.balance += amount;
    }

    public int getId() {
        return id;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public String getAccountName() {
        return accountName;
    }

    public double getAmount() {
        return amount;
    }

    public String getPostedAt() {
        return postedAt;
    }

    public String getNote() {
        return note;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        if (receiverName == null) {
            return id + "|" + accountName + "|" + amount + "|" + postedAt + "|" + note;
        } else {
            return id + "|" + accountName + "|" + receiverName + "|" + amount + "|" + postedAt + "|" + note;
        }
    }

    public long getTimestamp() {
        return 0;
    }

}