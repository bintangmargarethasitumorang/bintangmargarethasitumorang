package fintech.driver;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

import fintech.model.Account;
import fintech.model.Transaction;

/**
 * 12S21006 - Weny Sihol Marto Sitinjak
 * 12S21023 - Bintang Margaretha Situmorang
 */

public class Driver2 {
    final static Scanner scanner = new Scanner(System.in);
    private static final long REVERT_TIME_LIMIT = 10 * 60 * 1000; // 10 minutes in milliseconds
    static int transactionId = 1;
    static List<Account> accounts = new ArrayList<>();
    static List<Transaction> transactions = new ArrayList<>();

    public static void main(String[] args) {
        List<String> inputList = new ArrayList<>();
        do {
            String input = scanner.nextLine();
            if (input.equals("---")) {
                break;
            }
            inputList.add(input);
        } while (true);

        for (String input : inputList) {
            String[] command = input.split("#");
            if (command[0].equals("create-account")) {
                createAccount(command[1], command[2]);
            } else if (command[0].equals("find-account")) {
                findAccount(command[1]);
            } else if (command[0].equals("create-transaction")) {
                // search recipient
                boolean recipientFound = false;
                for (Account data : accounts) {
                    if (data.getAccountName().equals(command[2].trim().toLowerCase())) {
                        recipientFound = true;
                        break;
                    }
                }
                if (recipientFound) {
                    createTransactionWithRecipient(command[1], command[2], Double.parseDouble(command[3]), command[4],
                            command[5]);
                } else {
                    createTransaction(command[1], Double.parseDouble(command[2]), command[3], command[4]);
                }
            } else if (command[0].equals("show-account")) {
                showAccount(command[1]);
            } else if (command[0].equals("show-accounts")) {
                showAccounts();
            } else if (command[0].equals("remove-account")) {
                removeAccount(command[1]);
            } else if (command[0].equals("revert-transaction")) {
                revertTransaction(command[1], command[2], command[3]);
            }
        }
    }

    private static void revertTransaction(String owner, String id, String postedAt) {
        Transaction oldTransaction = null;
        // find transaction by Id
        for (Transaction data : transactions) {
            if (data.getId() == Integer.parseInt(id)) {
                oldTransaction = data;
                break;
            }
        }
    
        if (oldTransaction == null) {
            return;
        }
    
        long transactionAge = System.currentTimeMillis() - oldTransaction.getTimestamp();
        if (transactionAge > REVERT_TIME_LIMIT) {
            return;
        }
    
        if (oldTransaction.getReceiverName() != null) {
            // revert transaction with recipient
            createTransactionWithRecipient(owner, oldTransaction.getAccountName(), oldTransaction.getAmount() * -1,
                    postedAt, "REVERT: " + oldTransaction.getNote());
        } else {
            // revert transaction without recipient
            createTransaction(owner, oldTransaction.getAmount() * -1, postedAt,
                    "REVERT: " + oldTransaction.getNote());
            // check owner balance
        }
    }
    
    public static void createAccount(String owner, String accountName) {
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                return;
            }
        }
        Account account = new Account(owner, accountName);
        accounts.add(account);
        System.out.println(account);
    }

    public static void findAccount(String accountName) {
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                System.out.println(data);
                return;
            }
        }
    }

    private static void removeAccount(String accountName) {
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                accounts.remove(data);
                return;
            }
        }
    }

    public static void createTransactionWithRecipient(String accountName, String recipient, double amount,
            String postedAt, String note) {
        Transaction transaction = new Transaction(transactionId, accountName, recipient, amount, postedAt, note);
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                data.setBalance(data.getBalance() - transaction.getAmount());
                if (data.getBalance() < 0) {
                    // rollback
                    data.setBalance(data.getBalance() + transaction.getAmount());
                    transactions.remove(transaction);
                    return;
                }
                break;
            }
        }
        for (Account data : accounts) {
            if (data.getAccountName().equals(recipient.trim().toLowerCase())) {
                data.setBalance(data.getBalance() + transaction.getAmount());
                if (data.getBalance() < 0) {
                    // rollback
                    data.setBalance(data.getBalance() - transaction.getAmount());
                    transactions.remove(transaction);
                    return;
                }
                break;
            }
        }
        transactions.add(transaction);
        transactionId++;
    }

    public static void createTransaction(String accountName, double amount, String postedAt, String note) {
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                Transaction transaction = new Transaction(transactionId, data.getAccountName(), amount, postedAt, note);
                transactions.add(transaction);
                data.setBalance(data.getBalance() + transaction.getAmount());
                if (data.getBalance() < 0) {
                    // rollback
                    data.setBalance(data.getBalance() - transaction.getAmount());
                    transactions.remove(transaction);
                    return;
                }
                transactionId++;
                return;
            }
        }
    }

    public static void showAccount(String accountName) {
        boolean found = false;
        for (Account data : accounts) {
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                System.out.println(data);
                found = true;
                break;
            }
        }
        if (!found) {
            return;
        }

        transactions.sort(Comparator.comparing(Transaction::getPostedAt));
        for (Transaction data : transactions) {
            if (data.getReceiverName() != null) {
                if (data.getReceiverName().equals(accountName.trim().toLowerCase())) {
                    System.out.println(data);
                }
            }
            if (data.getAccountName().equals(accountName.trim().toLowerCase())) {
                System.out.println(data);
            }
        }
    }

    public static void showAccounts() {
        accounts.sort(Comparator.comparing(Account::getAccountName));
        transactions.sort(Comparator.comparing(Transaction::getPostedAt));
        for (Account data : accounts) {
            System.out.println(data);
            for (Transaction t : transactions) {
                if (t.getReceiverName() != null) {
                    if (t.getReceiverName().equals(data.getAccountName())) {
                        System.out.println(t);
                    }
                }
                if (t.getAccountName().equals(data.getAccountName())) {
                    System.out.println(t);
                }
            }
        }
    }
}
