// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "libs/dorm.h"
#include "libs/student.h"

int main(int _argc, char **_argv){
    struct dorm_t *dorms = malloc(100 * sizeof(struct dorm_t));
    struct student_t *students = malloc(100 * sizeof(struct student_t));
    char data[100];
    char id[10];
    char name[25];
    char year[5];
    char dorm_name[10];
    unsigned short capacity;
    char *kata;
    int std=0, drm=0;
    int idx_dorm, idx_student;
    while (1==1)
    {
        fflush(stdin);
        data[0] = '\0';
        int x = 0;
        do
        {
            char k = getchar();
            if (k == '\n')
            {
                break;
            }
            if (k == '\r')
            {
                continue;
            }
            data[x] = k;
            data[x++] = '\0';
        } while (1==1);
        kata = strtok(data, "#");
        if (strcmp(kata, "student-add")==0)
        {
            kata = strtok(NULL, "#");
            strcpy(id, kata);
            kata = strtok(NULL, "#");
            strcpy(name, kata);
            kata = strtok(NULL, "#");
            strcpy(year, kata);
            kata = strtok(NULL, "#");
            if (strcmp(kata, "female")==0)
            {
                students[std] = create_student(id, name, year, GENDER_FEMALE);
            } 
            else if (strcmp(kata, "male")==0)
            {
                students[std] = create_student(id, name, year, GENDER_MALE);
            }
            ++std;
        } 
        else if (strcmp(data, "dorm-add")==0)
        {
            kata = strtok(NULL, "#");
            strcpy(dorm_name, kata);
            kata = strtok(NULL, "#");
            capacity = atoi(kata);
            kata = strtok(NULL, "#");
            if (strcmp(kata, "female")==0)
            {
                dorms[drm] = create_dorm(dorm_name, capacity, GENDER_FEMALE);
            } 
            else if (strcmp(kata, "male")==0)
            {
                dorms[drm] = create_dorm(dorm_name, capacity, GENDER_MALE);
            }
            ++drm;
        }
        else if (strcmp(kata, "student-print-all")==0) 
        {
            void (*pf)(struct student_t *_student, int count) = NULL;
            pf = print_student;
            pf(students, std);
        } 
        else if (strcmp(kata, "student-print-all-detail")==0) 
        {
            void (*pf)(struct student_t *_student, int count) = NULL;
            pf = print_student_detail;
            pf(students, std);
        }
        else if (strcmp(kata, "dorm-print-all")==0) 
        {
            void (*pf)(struct dorm_t *_dorm, int count) = NULL;
            pf = print_dorm;
            pf(dorms, drm);
        } 
        else if (strcmp(kata, "dorm-print-all-detail")==0) 
        {
            void (*pf)(struct dorm_t *_dorm, int count) = NULL;
            pf = print_dorm_detail;
            pf(dorms, drm);
        } 
        else if (strcmp(kata, "assign-student")==0) 
        {
            kata = strtok(NULL, "#");
            strcpy(id, kata);
            kata = strtok(NULL, "#");
            strcpy(dorm_name, kata);
            idx_student = 0;
            idx_dorm = 0;
            for (int x = 0; x < std; ++x)
            {
                if(strcmp(students[x].id, id)==0)
                {
                    idx_student = x;
                    break;
                }
            }
            for (int x = 0; x < std; ++x)
            {
                if(strcmp(dorms[x].name, dorm_name)==0)
                {
                    idx_dorm = x;
                    break;
                }
            }
            void (*pf)(struct student_t *_student,struct dorm_t *_dorm, char *id, char *dorm_name) = NULL;
            pf = assign_student;
            pf(&students[idx_student], &dorms[idx_dorm], id, dorm_name);
        } 
        else if (strcmp(kata, "move-student")==0) 
        {
            kata = strtok(NULL, "#");
            strcpy(id, kata);
            kata = strtok(NULL, "#");
            strcpy(dorm_name, kata);
            idx_student = 0;
            idx_dorm = 0;
            for (int x = 0; x < std; ++x){
                if(strcmp(students[x].id, id)==0)
                {
                    idx_student = x;
                    break;
                }
            }
            for (int x = 0; x < drm; ++x){
                if(strcmp(dorms[x].name, dorm_name)==0)
                {
                    idx_dorm = x;
                    break;
                }
            }
            if (students[idx_student].dorm==NULL)
            {
                void (*pf)(struct student_t *_student,struct dorm_t *_dorm, char *id, char *dorm_name) = NULL;
                pf = assign_student;
                pf(&students[idx_student], &dorms[idx_dorm], id, dorm_name);
            } 
            else 
            {
                for (int x = 0; x < drm; ++x)
                {
                    if(strcmp(students[idx_student].dorm->name, dorms[x].name)==0)
                    {
                        void (*pf)(struct student_t *_student, struct dorm_t *_dorm, struct dorm_t *old_dorm, char *id, char *dorm_name) = NULL;
                        pf = move_student;
                        pf(&students[idx_student], &dorms[idx_dorm], &dorms[x], id, dorm_name);
                        break;
                    }
                }
            }
        }
        else if(strcmp(kata, "---")==0)
        {
            break;
        } 
    }
    free(students);
    free(dorms);
    return 0;
}