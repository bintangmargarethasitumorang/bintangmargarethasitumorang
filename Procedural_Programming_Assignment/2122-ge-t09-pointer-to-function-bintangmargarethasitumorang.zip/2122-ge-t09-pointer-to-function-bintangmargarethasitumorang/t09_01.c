// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "./libs/dorm.h"
#include "./libs/student.h"

int main(int _argc, char **_argv){
    struct dorm_t *dorms = malloc(100 * sizeof(struct dorm_t));
    struct student_t *students = malloc(100 * sizeof(struct student_t));
    char data[100];
    char id[10];
    char name[25];
    char year[5];
    char dorm_name[10];
    unsigned short capacity;
    char *kata;
    int std=0, dr=0;

    while (1==1)
    {
        fflush(stdin);
        data[0] = '\0';
        int x = 0;
        do
        {
            char k = getchar();
            if (k == '\n')
            {
                break;
            }
            if (k == '\r')
            {
                continue;
            }
            data[x] = k;
            data[x++] = '\0';
        } while (1==1);
        kata = strtok(data, "#");
        if (strcmp(kata, "student-add")==0)
        {
            kata = strtok(NULL, "#");
            strcpy(id, kata);
            kata = strtok(NULL, "#");
            strcpy(name, kata);
            kata = strtok(NULL, "#");
            strcpy(year, kata);
            kata = strtok(NULL, "#");
            if (strcmp(kata, "male")==0){
                students[std] = create_student(id, name, year, GENDER_MALE);
            } else if (strcmp(kata, "female")==0){
                students[std] = create_student(id, name, year, GENDER_FEMALE);
            }
            std++;
        }
        else if (strcmp(data, "dorm-add")==0)
        {
            kata = strtok(NULL, "#");
            strcpy(dorm_name, kata);
            kata = strtok(NULL, "#");
            capacity = atoi(kata);
            kata = strtok(NULL, "#");
            if (strcmp(kata, "male")==0){
                dorms[dr] = create_dorm(dorm_name, capacity, GENDER_MALE);
            } else if (strcmp(kata, "female")==0){
                dorms[dr] = create_dorm(dorm_name, capacity, GENDER_FEMALE);
            }
            dr++;
        }
        else if (strcmp(kata, "student-print-all")==0) 
        {
            void (*pf)(struct student_t *_student, int count) = NULL;
            pf = print_student;
            pf(students, std);
        } 
        else if (strcmp(kata, "student-print-all-detail")==0) 
        {
            void (*pf)(struct student_t *_student, int count) = NULL;
            pf = print_student_detail;
            pf(students, std);
        }
        else if (strcmp(kata, "dorm-print-all")==0) 
        {
            void (*pf)(struct dorm_t *_dorm, int count) = NULL;
            pf = print_dorm;
            pf(dorms, dr);
        } 
        else if (strcmp(kata, "dorm-print-all-detail")==0) 
        {
            void (*pf)(struct dorm_t *_dorm, int count) = NULL;
            pf = print_dorm_detail;
            pf(dorms, dr);
        } 
        else if(strcmp(kata, "---")==0)
        {
            break;
        } 
    }
    free(students);
    return 0;
}
