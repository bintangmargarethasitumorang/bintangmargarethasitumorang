// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang

#include <stdio.h>

int main(int _argv, char **_argc)
{
unsigned short level; 

scanf("%hu", &level);

switch (level) {
case 5:
  printf("milk\n");
case 4:
  printf("fruits\n");
case 3:
  printf("vegetables\n");
case 2:
  printf("side dishes\n");
case 1:
  printf("staple food\n");
}

switch (level) {
case 5:
  printf("perfect\n");
  break;
case 4:
  printf("very good\n");
  break;
case 3:
  printf("good\n");
  break;
case 2:
  printf("you need vegetables\n");
  break;
case 1:
  printf("you need side dishes\n");
}

return 0;
 
}
