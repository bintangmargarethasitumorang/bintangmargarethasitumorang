// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang

#include <stdio.h>

int main(int _argv, char **_argc)
{
  int i, value, result, input;
  char op;

  i = 1;
  scanf("%c", &op);
  if (op == '*'){
    value = 1;
  } 
  else if (op == '+'){
    value = 0;
  } 
  else if (op == '-'){
    value = 0;
  }

  while ((i < 5)){
  scanf("%i",&input);
  
  if (input == -1){
    printf("0");
  break;
  }

  if (op == '+'){
    result = value + input;
    value = result;
  }
  else if (op == '*'){
    result = value * input;
    value = result;
  }
  else if (op == '-'){
    result = value - input;
    result = -result;
    value = result;
  }

  printf("%i\n", result);
  ++i;
  }
  return 0;
}