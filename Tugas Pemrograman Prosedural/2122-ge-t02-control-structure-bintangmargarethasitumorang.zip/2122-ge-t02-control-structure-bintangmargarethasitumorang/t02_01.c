// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang

#include <stdio.h>

int main(int _argv, char **_argc)
{
  int n;
  unsigned int harga;
  float diskon, bayar, tempPrice;

  scanf("%d\n", &n);
  scanf("%i", &harga);

  tempPrice = n*harga;

  if (tempPrice > 500000)
  {
    diskon = tempPrice*0.15;
    bayar = tempPrice-diskon;
    printf("%.2f\n", diskon);
    printf("%.2f", bayar);
  }
  else if (tempPrice > 100000)
  {
    diskon = tempPrice*0.1;
    bayar = tempPrice-diskon;
    printf("%.2f\n", diskon);
    printf("%.2f", bayar);
  }
  else if (tempPrice > 50000)
  {
    diskon = tempPrice*0.05;
    bayar = tempPrice-diskon;
    printf("%.2f\n", diskon);
    printf("%.2f", bayar);
  }
  else if (tempPrice <= 50000)
  {
    printf("---\n");
    printf("%.2f", tempPrice);
  }

  return 0;

}
