// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang 

#include <stdio.h>

int main(int _argv, char **_argc)
{
  float a, b, c, d, sum, avg;
  
  scanf("%f\n", &a);
  scanf("%f\n", &b);
  scanf("%f\n", &c);
  scanf("%f", &d);

  sum = a+b+c+d;
  avg = sum/4;

  printf("%0.3f\n%0.3f", sum, avg);
  
  return 0;
}
