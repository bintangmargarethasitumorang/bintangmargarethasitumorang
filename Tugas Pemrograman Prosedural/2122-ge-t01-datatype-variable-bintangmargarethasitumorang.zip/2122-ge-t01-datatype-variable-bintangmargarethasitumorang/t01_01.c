// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang 

#include <stdio.h>

int main(int _argv, char **_argc)
{
  int angka, boolean;
  char huruf;
  float koma;

  scanf("%d\n", &angka);
  scanf("%c\n", &huruf);
  scanf("%d\n", &boolean);
  scanf("%f", &koma); 

  printf("%d\n%c\n%d\n%0.3f", angka, huruf, boolean, koma);  

  return 0;
}
