// 12S21016 - Kevin Unedo Samosir
// 12S21023 - Bintang Margaretha Situmorang 

#include <stdio.h>

int main(int _argv, char **_argc)
{
  int a, b,c, rshift, equality;

  scanf("%d\n", &a);
  scanf("%d\n", &b);
  scanf("%d", &c);
  
  rshift=a>>b;
  equality = rshift==c;
   

  printf("%d\n%d", rshift, equality);

  return 0;
}
