package fintech.model;

/**
 * 12S21006 - Weny Sihol Marto Sitinjak
 * 12S21023 - Bintang Margaretha Situmorang
 */
public class Transaction {
    private int id;
    private String accountName;
    private double balance = 0.0;
    private double amount = 0.0;
    private String postedAt;
    private String note;

    public Transaction(int id, String accountName, double amount, String postedAt, String note) {
        this.id = id;
        this.accountName = accountName;
        this.amount = amount;
        this.postedAt = postedAt;
        this.note = note;
        this.balance += amount;
    }

    public String getAccountName() {
        return accountName;
    }

    public double getAmount() {
        return amount;
    }

    public String getPostedAt() {
        return postedAt;
    }

    public String getNote() {
        return note;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return id + "|" + accountName + "|" + amount + "|" + postedAt + "|" + note;
    }

}
