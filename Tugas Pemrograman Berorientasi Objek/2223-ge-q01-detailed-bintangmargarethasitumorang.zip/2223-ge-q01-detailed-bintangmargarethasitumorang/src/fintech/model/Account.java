package fintech.model;

/**
 * 12S21006 - Weny Sihol Marto Sitinjak
 * 12S21023 - Bintang Margaretha Situmorang
 */
public class Account {

    private String owner;
    private String accountName;
    private double balance = 0.0;

    public Account(String owner, String accountName) {
        this.owner = owner;
        this.accountName = accountName;
    }

    public String getOwner() {
        return owner;
    }

    public String getAccountName() {
        return accountName;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return accountName + "|" + owner + "|" + balance;
    }

    public void setBalance(double v) {
        this.balance = v;
    }
}
