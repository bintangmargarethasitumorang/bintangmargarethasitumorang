package fintech.driver;

import fintech.model.Account;
import fintech.model.Transaction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
* 12S21006 - Weny Sihol Marto Sitinjak
* 12S21023 - Bintang Margaretha Situmorang
 */
public class Driver2 {

    final static Scanner scanner = new Scanner(System.in);

    public static void main(String[] _args) {
        int i = 1;
        List<Account> accounts = new ArrayList<>();
        List<Transaction> transactions = new ArrayList<>();
        List<String> inputList = new ArrayList<>();
        do {
            String input = scanner.nextLine();
            if (input.equals("---")) {
                break;
            }
            inputList.add(input);
        } while (true);
        for (String input : inputList) {
            String[] command = input.split("#");
            if (command[0].equals("create-account")) {
                Account account = new Account(command[1], command[2]);
                accounts.add(account);
                System.out.println(account);
            } else if (command[0].equals("find-account")) {
                for (Account data : accounts) {
                    if (data.getAccountName().equals(command[1].trim().toLowerCase())) {
                        System.out.println(data);
                        break;
                    }
                }
            } else if (command[0].equals("create-transaction")) {
                for (Account data : accounts) {
                    if (data.getAccountName().equals(command[1].trim().toLowerCase())) {
                        Transaction transaction = new Transaction(i, data.getAccountName(),
                                Double.parseDouble(command[2]),
                                command[3], command[4]);
                        transactions.add(transaction);
                        data.setBalance(data.getBalance() + transaction.getAmount());
                        i++;
                        break;
                    }
                }
            } else if (command[0].equals("show-account")) {
                for (Account data : accounts) {
                    if (data.getAccountName().equals(command[1].trim().toLowerCase())) {
                        System.out.println(data);
                        break;
                    }
                }

                for (Transaction data : transactions) {
                    if (data.getAccountName().equals(command[1].trim().toLowerCase())) {
                        System.out.println(data);
                    }
                }
            } else if (command[0].equals("show-accounts")) {
                accounts.sort(Comparator.comparing(Account::getAccountName));
                transactions.sort(Comparator.comparing(Transaction::getPostedAt));
                for (Account data : accounts) {
                    System.out.println(data);
                    for (Transaction t : transactions) {
                        if (t.getAccountName().equals(data.getAccountName())) {
                            System.out.println(t);
                        }
                    }
                }
            }
        }
    }

}