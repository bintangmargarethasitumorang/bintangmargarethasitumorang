package pbo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student {
    @Id
    @Column(name="NIM", nullable = false, length = 10)
    private String NIM;
    @Column(name="nama", nullable = false, length = 30)
    private String nama;
    @Column(name="prodi", nullable = false, length = 20)
    private String prodi;

    public Student(String NIM, String nama, String prodi) {
        this.NIM = NIM;
        this.nama = nama;
        this.prodi = prodi; 
    }
    
    public String getNIM() {
        return NIM;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String getProdi() {
        return prodi;
    }
    
    public void setProdi(String prodi) {
        this.prodi = prodi;
    }
    
    @Override
    public String toString() {
        return NIM + "|" + nama + "|" + prodi;
    }    
    
}





