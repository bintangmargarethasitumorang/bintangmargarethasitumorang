package pbo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import pbo.model.Student;

import java.util.*;

/**
 * 12S21006 - Weny Sihol Marito Sitinjak 
 * 12S21023 - Bintang Margaretha Situmorang
 */

public class App {
    private static EntityManagerFactory factory;
    private static EntityManager entityManager;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        factory = Persistence.createEntityManagerFactory("study_plan_pu");
        entityManager = factory.createEntityManager();

        String command;
        while (scanner.hasNextLine()) { // Periksa ketersediaan baris berikutnya
            command = scanner.nextLine();
            if (command.isEmpty()) {
                break;
            }

            String[] tokens = command.split("#");

            for (int i = 0; i < tokens.length; i++) {
                if (tokens[i].equals("student-add")) {
                    studentAdd(tokens);
                } else if (tokens[i].equals("student-show-all")) {
                    studentShowAll();
                } else {
                    break;
                }
            }
        }

        entityManager.getTransaction().begin();
        entityManager.createQuery("DELETE FROM Student s").executeUpdate();
        entityManager.getTransaction().commit();
        entityManager.close();
        factory.close();
        scanner.close();
    }

    private static void studentAdd(String[] tokens) {
        String NIM = tokens[2];
        String nama = tokens[1];
        String prodi = tokens[0];

        List<Student> students = entityManager.createQuery(
                "SELECT s FROM Student s WHERE s.NIM = :NIM", Student.class)
                .setParameter("NIM", NIM)
                .getResultList();
        if (!students.isEmpty()) {
            return;
        }

        Student student = new Student(NIM, nama, prodi);
        entityManager.getTransaction().begin();
        entityManager.persist(student);
        entityManager.getTransaction().commit();

        String output = NIM + "|" + nama + "|" + prodi;
        System.out.println(output);
    }

    private static void studentShowAll() {
        List<Student> students = entityManager.createQuery(
                "SELECT s FROM Student s ORDER BY s.NIM ASC", Student.class)
                .getResultList();

        for (Student student : students) {
            String output = student.getNIM() + "|" + student.getNama() + "|" + student.getProdi();
            System.out.println(output);
        }
    }
}
