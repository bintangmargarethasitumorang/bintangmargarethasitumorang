package fintech.driver;
import fintech.model.*;
import java.util.Scanner;

/**
 * @author 12S21006 Weny Sihol Mario Sitinjak
 * @author 12S21023 Bintang Margaretha Situmorang
 */
public class Driver1 {

    public static void main(String[] _args) {
        Scanner scanner = new Scanner(System.in);

        // command
        String command = scanner.nextLine();
        // owner
        String owner = scanner.nextLine();
        // account.name
        String name = scanner.nextLine();

        Account account = new Account(owner, name);

        System.out.println(account);

        scanner.close();
    }

}