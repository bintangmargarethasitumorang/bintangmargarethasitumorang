package fintech.driver;

import fintech.model.*;
import java.util.Scanner;

/**
 * @author 12S21006 Weny Sihol Mario Sitinjak
 * @author 12S21023 Bintang Margaretha Situmorang
 */
public class Driver2 {

    public static void main(String[] _args) {
        Scanner scanner = new Scanner(System.in);

        // command
        String command = scanner.nextLine();
        // owner
        String owner = scanner.nextLine();
        // account.name
        String name = scanner.nextLine();

        String command2 = scanner.nextLine();
        String accountname = scanner.nextLine();
        float amount = scanner.nextFloat();
        String postedat = scanner.nextLine();
        String note = scanner.nextLine();
        String note2 = scanner.nextLine();

        Account account = new Account(owner, name);

        int id = 1;

        Transaction transaction = new Transaction(id, accountname, amount, note, note2);

        System.out.println(account);

        System.out.println(transaction);

        scanner.close();
    }

}
