package fintech.model;

import java.sql.Date;

/**
 * @author 12S21006 Weny Sihol Mario Sitinjak
 * @author 12S21023 Bintang Margaretha Situmorang
 */
public class Transaction {

    // class definition

    private int id;
    private String accountname;
    private float amount;
    private String postdate;
    private String note;

    public Transaction(int _id, String _accountname, float _amount, String _postdate, String _note) {
        this.id = _id;
        this.accountname = _accountname;
        this.amount = _amount;
        this.postdate = _postdate;
        this.note = _note;
    }

    public int getId() {
        return id;
    }

    public String getAccountname() {
        return accountname;
    }

    public float getAmount() {
        return amount;
    }

    public String getPostdate() {
        return postdate;
    }

    public String getNote() {
        return note;
    }

    public String toString() {
        return this.id + "|" + this.accountname + "|" + this.amount + "|" + this.postdate + "|" + this.note + "|"
                + this.amount;
    }

}
